// PASSWORD STRENGTH METER
const passwordInput = document.getElementById("signupPassword");
const strengthBar = document.getElementById("passwordStrength");

if (passwordInput) {
    passwordInput.addEventListener("input", () => {
        const value = passwordInput.value;
        let strength = 0;

        if (value.length > 6) strength++;
        if (value.match(/[A-Z]/)) strength++;
        if (value.match(/[0-9]/)) strength++;
        if (value.match(/[^A-Za-z0-9]/)) strength++;

        const colors = ["#e64a19", "#ffb300", "#a5d6a7", "#2e7d32"];
        strengthBar.style.background = colors[strength] || "#e0e0e0";
    });
}

// SIGNUP LOGIC
const signupForm = document.getElementById("signupForm");
const signupFeedback = document.getElementById("signupFeedback");

if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const email = document.getElementById("signupEmail").value;
        const password = document.getElementById("signupPassword").value;

        localStorage.setItem("userEmail", email);
        localStorage.setItem("userPassword", password);

        signupFeedback.textContent = "Account created successfully!";
        signupFeedback.style.color = "#2e7d32";

        setTimeout(() => {
            window.location.href = "index.html";   // ← redirect to homepage
        }, 1200);
    });
}

// LOGIN LOGIC
const loginForm = document.getElementById("loginForm");
const loginFeedback = document.getElementById("loginFeedback");

if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const email = document.getElementById("loginEmail").value;
        const password = document.getElementById("loginPassword").value;

        const storedEmail = localStorage.getItem("userEmail");
        const storedPassword = localStorage.getItem("userPassword");

        if (email === storedEmail && password === storedPassword) {
            loginFeedback.textContent = "Login successful!";
            loginFeedback.style.color = "#2e7d32";

            setTimeout(() => {
                window.location.href = "index.html";   // ← redirect to homepage
            }, 1200);
        } else {
            loginFeedback.textContent = "Incorrect email or password.";
            loginFeedback.style.color = "#e64a19";
        }
    });
}

